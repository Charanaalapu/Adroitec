from flask import Flask
from Code_Base.email_sender import configure_mail
from Routes.login_route import login_route,signup_route
from Routes.reset_password_route import reset_password_link_gen_route,reset_password

import os

app = Flask(__name__)

# Configure Flask app for Flask-Mail using environment variables
app.config['MAIL_SERVER'] = "smtp.gmail.com"
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = "corundum.cdat@gmail.com"
app.config['MAIL_PASSWORD'] ="xeru migv adzk xyys"  # Use environment variable for password
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

# Initialize Flask-Mail
configure_mail(app)

app.register_blueprint(login_route, url_prefix='/login')
app.register_blueprint(signup_route, url_prefix='/signup')
app.register_blueprint(reset_password_link_gen_route, url_prefix='/resetPassLinkGen')
app.register_blueprint(reset_password, url_prefix='/resetPass')


if __name__ == '__main__':
    app.run(debug=True)
