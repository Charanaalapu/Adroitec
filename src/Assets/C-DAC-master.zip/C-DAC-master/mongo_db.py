from flask import request
import pymongo


# local_url = "mongodb://localhost:27017/" 
# client = pymongo.MongoClient(local_url)
url="mongodb+srv://corundum:corundum#2211@cluster0.b9usv17.mongodb.net/?retryWrites=true&w=majority"
client=pymongo.MongoClient(url)

db = client['C-DAC']

user_collection=db['Users']


