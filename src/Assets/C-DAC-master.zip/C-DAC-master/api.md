signup
uri----http://127.0.0.1:5000/signup  -----POST

body{
    "email":"nesruns47@gmail.com",
    "role":"admin",
    "name":"nesru"
}

400 -- missing
404 --user not found

reset password
 http://127.0.0.1:5000/resetPass  POST

 {
    "password":"nes"
}
400 params missing
404 user not found

//
reset password link

http://127.0.0.1:5000/resetPassLinkGen   POST

{
    "email":"nesruns47@gmail.com"
}
400 params missing
404 user not found

//
login
http://127.0.0.1:5000/login  POST

{
    "email":"nes47@gmail.com",
    "password":"nes"
}