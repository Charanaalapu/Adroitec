
from flask_mail import Mail, Message
from .authorization import create_access_token

# create the mail instance
mail = Mail()

# configure mail in your app
def configure_mail(app):
    mail.init_app(app)

# your email-sending function

def send_email(email):
    
    try:
        reset_link = f"http://127.0.0.1:3000/resetPass?token={create_access_token(email)}"
        subject = 'Reset Password'

        html_content = f"""

                <!DOCTYPE html>
                <html lang="en">

                <head>
                    <meta charset="UTF-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Reset Password</title>
                    <style>
                        .email-container {{
                            max-width: 600px;
                            margin: auto;
                            padding: 20px;
                            background-color: #ffcccc; /* Light red background color */
                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                        }}

                        body {{
                            background-color: #f0f8ff; /* Light blue background color */
                            color: #333; /* Dark text color */
                            font-family: Arial, sans-serif;
                            margin: 20px; /* Add some margin for better readability */
                        }}

                        p {{
                            font-size: 16px;
                            line-height: 1.5;
                            margin-bottom: 15px;
                        }}

                        a {{
                            color: #0066cc; /* Blue link color */
                            text-decoration: none;
                            font-weight: bold;
                        }}

                        a:hover {{
                            text-decoration: underline;
                        }}

                        .reset-button {{
                            display: inline-block;
                            padding: 10px 15px;
                            background-color: #add8e6; /* Light blue button color */
                            color: #333; /* Dark text color for button */
                            border: none;
                            border-radius: 5px;
                            font-size: 16px;
                            cursor: pointer;
                            text-decoration: none;
                        }}

                        .reset-button:hover {{
                            background-color: #87ceeb; /* Slightly darker shade on hover */
                        }}
                        
                    </style>
                </head>

                <body>
                    <div class="email-container">
                        <p>Hello {email},</p>
                        <br>
                        <p>Click this button for reset password</p>
                        <br>
                        <a class="reset-button" href="{reset_link}">Reset Password</a>
                        <br>
                        
                        <p>Thank you</p>
                    </div>
                </body>

                </html>

                """

        text_content = f"Hello,\nUsername: {email}\nReset password link: {reset_link}\nThank you"

        msg = Message(subject, sender='corundum.cdat@gmail.com', recipients=[email])
        msg.body = text_content
        msg.html = html_content

        mail.send(msg)
        return 'Email sent!', 200

    except Exception as e:
        print(f'Error sending email: {e}')
        return 'Server error', 500
