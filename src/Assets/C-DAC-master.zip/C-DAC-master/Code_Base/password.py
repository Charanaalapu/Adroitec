import logging
import random
import string
import bcrypt

from Code_Base.logging import configure_logger

logger = configure_logger("password",'logs/password.log', logging.INFO)

def generate_custom_password(length=20):
    
    characters = string.ascii_letters + string.digits + "%rfgvt$%%fhgbhj66hhb%%333@#56v4#$#"
    custom_password = ''.join(random.choice(characters) for _ in range(length))
    return custom_password




def hash_password(password):
    
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password


def verify_password(provided_password, stored_password):
  
    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_password)
 

