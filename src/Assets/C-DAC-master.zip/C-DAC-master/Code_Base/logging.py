import logging


def configure_logger(logger_name, log_file_path, log_level=logging.INFO):
    try:
        logger = logging.getLogger(logger_name)
        handler = logging.FileHandler(log_file_path)
        handler.setLevel(log_level)
        formatter = logging.Formatter(' %(asctime)s - %(levelname)s - Line No= %(lineno)d - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger
    except Exception as e:
        return "Server error", 500