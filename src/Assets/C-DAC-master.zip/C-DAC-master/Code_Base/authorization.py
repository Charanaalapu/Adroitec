import jwt, datetime
from mongo_db import user_collection


class InvalidTokenError(Exception):
    pass
class NotAuthorizedError(Exception):
    pass


def create_access_token(email):
    return jwt.encode({
        'email': email,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2),
        'iat': datetime.datetime.utcnow()
    }, 'tdtyfuhcu', algorithm='HS256')


def decode_access_token(token):
    try:
        payload = jwt.decode(token, 'tdtyfuhcu', algorithms='HS256')

        return payload['email']
    except:
        return 0

    
def validate_token(token):
    email=decode_access_token(token)
    user=user_collection.find_one({"email":email})
    if not user:
        raise InvalidTokenError("Invalid token, please log in again")
    else:
        return 
       

def check_for_email(token):
    email=decode_access_token(token)
    user=user_collection.find_one({"email":email})
    if user:
        return user
    else:
        raise FileNotFoundError("user not found contact admin")
    
  
    
     
    
  