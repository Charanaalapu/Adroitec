import logging
from Code_Base.authorization import decode_access_token
from Code_Base.email_sender import send_email
from Code_Base.logging import configure_logger
from Code_Base.password import hash_password
from mongo_db import user_collection
import threading
from flask import Blueprint, jsonify, request

logger = configure_logger("rest_password",'logs/reset_pass.log', logging.INFO)

reset_password_link_gen_route = Blueprint('reset_password_link_gen', __name__)
@reset_password_link_gen_route.route('', methods=['POST'])
def reset_password_link_gen():
    try:
        data = request.json 
        email = data.get('email')
        
        if not email:
            raise ValueError("Please provide email in the request body")
        
       
        user = list(user_collection.find({"email": email}))
        
        if not user:
            raise FileNotFoundError("User not found")

        else:
            send_email(email)
            return jsonify({"message": "OK"}), 200

    except ValueError as e:
        return str(e), 400
    except FileNotFoundError as e:
        return str(e), 404
    except Exception as e:
        logger.warning("reset_password_link_gen ==> %s", str(e))
        return "Server error", 500
    


reset_password = Blueprint('reset_password', __name__)
@reset_password.route('', methods=['POST'])
def reset_pass():
    try:
        token = request.headers.get('Authorization')
        if not (token):
            raise ValueError("token is missing")
        
        data = request.json 
        password = data.get('password')
        
        if not password:
            raise ValueError("Please provide new password")
        
        email = decode_access_token(token)
      
        user=list(user_collection.find_one({"email":email}))
     
        if user:
            user_collection.update_one(
                {"email": email}, 
                {"$set": {"password": hash_password(password)}}
            )
            return "Successfully updated", 200
        
        else:
            raise FileNotFoundError("User Not found")


    except ValueError as e:
        return str(e), 400
    except FileNotFoundError as e:
        return str(e), 404
    except Exception as e:
        logger.warning("Reset_password ==> %s", str(e))
        return "Server error", 500    