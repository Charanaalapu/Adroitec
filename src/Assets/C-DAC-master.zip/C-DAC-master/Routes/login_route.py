import logging
import threading
from Code_Base.authorization import create_access_token
from Code_Base.logging import configure_logger
from mongo_db import user_collection
from Code_Base.password import verify_password
from Code_Base.email_sender import send_email

from flask import Blueprint, jsonify, request


logger = configure_logger("login_logger",'logs/login.log', logging.INFO)

login_route = Blueprint('login', __name__)
@login_route.route('', methods=['POST'])
def login():

    try:
        data = request.json 
        email = data.get('email')
        password = data.get('password')

        
        if not all((email,password)):
            raise ValueError("params is missing")

        user=user_collection.find_one({'email':email})
        if not user:
            raise FileNotFoundError("user not found, contact admin")
        
        if 'password' not in user:
            return "incorrect credentils",401
        
        if user and verify_password(password, user["password"]):
            token = create_access_token(email)
            result={
                "token":token,
                "role":user['role']
            }
            return result, 200
        else:
            return jsonify({"message": "Incorrect credentials"}), 401

    except ValueError as e:
        return jsonify({"message": str(e)}), 400
    except FileNotFoundError as e:
        return jsonify({"message": str(e)}), 404
    except Exception as e:
        logger.warning("login ==> %s",str(e)) 
        return jsonify({"message": "Server error"}), 500    
    

signup_route = Blueprint('signup', __name__)
@signup_route.route('', methods=['POST'])
def signup():
    try:

        data = request.json 
        email = data.get('email')
        name = data.get('name')
        role = data.get('role')

        if not all((email,name,role)):
            raise ValueError("params is missing")
        
        if role not in ["admin", "user"]:
            raise ValueError("role must be user or admin")  
        
        user=user_collection.find_one({'email':email})
        if user:
            raise FileExistsError("Email already exists try reset password")
        
        user_collection.insert_one({
            "email":email,
            "role":role
        })

        send_email(email)
        return "check email for login",200

    except ValueError as e:
        return jsonify({"message": str(e)}), 400
    except FileExistsError as e:
        return jsonify({"message": str(e)}), 409
    except FileNotFoundError as e:
        return jsonify({"message": str(e)}), 404
    except Exception as e:
        logger.warning("login ==> %s",str(e)) 
        return jsonify({"message": "Server error"}), 500     
    